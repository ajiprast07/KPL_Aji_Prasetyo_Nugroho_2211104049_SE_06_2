const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());

let mahasiswa = [
  { nama: "Aji Prasetyo Nugroho", nim: "2211104049" },
  { nama: "Anggota 2", nim: "1302010002" },
  { nama: "Anggota 3", nim: "1302010003" }
];

// GET seluruh mahasiswa
app.get('/api/mahasiswa', (req, res) => {
  res.json(mahasiswa);
});

// GET mahasiswa berdasarkan index
app.get('/api/mahasiswa/:index', (req, res) => {
  const index = parseInt(req.params.index);
  if (mahasiswa[index]) {
    res.json(mahasiswa[index]);
  } else {
    res.status(404).json({ message: "Mahasiswa tidak ditemukan" });
  }
});

// POST mahasiswa baru
app.post('/api/mahasiswa', (req, res) => {
  const { nama, nim } = req.body;
  if (nama && nim) {
    mahasiswa.push({ nama, nim });
    res.status(201).json({ message: "Mahasiswa ditambahkan", data: { nama, nim } });
  } else {
    res.status(400).json({ message: "Data tidak lengkap" });
  }
});

// DELETE mahasiswa berdasarkan index
app.delete('/api/mahasiswa/:index', (req, res) => {
  const index = parseInt(req.params.index);
  if (mahasiswa[index]) {
    const deleted = mahasiswa.splice(index, 1);
    res.json({ message: "Mahasiswa dihapus", data: deleted[0] });
  } else {
    res.status(404).json({ message: "Mahasiswa tidak ditemukan" });
  }
});

app.listen(PORT, () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);
});
